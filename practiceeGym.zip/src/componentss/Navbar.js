import "./comp.css"
import { Link } from "react-router-dom";

function Navbar() {
    return(
        <div className="nav">
            
        <img className="img" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVr5BYeKOyupQIhvm8u5QUGiSAA_8hBmy0mQ&s"/>

        <h1 className="title">
                FitLife Gym
            </h1>

        <div className="nv">
         <Link to = '/' className = "comps">Home</Link>
         <Link to = '/signin' className = "comps">SignIn</Link>
         <Link to = '/signup' className = "comps">SignUp</Link>
         <Link to = '/about ' className = "comps">About Us</Link>
        </div>
        </div>
    )
}
export default Navbar;