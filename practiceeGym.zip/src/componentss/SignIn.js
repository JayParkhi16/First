import "./comp.css"
import "./comp2.css"
import "./comp3in.css"
import { useState } from "react";

function SignIn() {

  var [gym,setGym] = useState({Gid:"", email:"", password:""});
  var handleChange = (e) => {
    var {name, value} = e.target;
    setGym({...gym,[name]:value});
  }

    return(
     
        <div className="bck">

     <h2>{gym.Gid}</h2>
     <h2>{gym.email}</h2>
     <h2>{gym.password}</h2>

          <div class="signin-container">
    <div class="signin-image"></div>
    <div class="signin-form">
      <div className="titlein">Sign In</div>
      <div >
      <input className="ln3" name="Gid" placeholder="Gym-Id" value={gym.Gid} onChange={handleChange} /> <br/> <br/>
        <input className="ln3" name="email" placeholder="Email" value={gym.email} onChange={handleChange} /> <br/> <br/>
        <input className="ln3" name="password" placeholder="Password" value={gym.password} onChange={handleChange} /> <br/> <br/>
        <button type="submit">Sign In</button>
        
      </div>
      <p className="ln">Don't have an account? <a className="ln2" href="/signup">Sign Up</a></p>
    </div>
  </div>
  </div>
  )
  }
    
export default SignIn;