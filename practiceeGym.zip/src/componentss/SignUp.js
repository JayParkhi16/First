import "./comp.css"
function SignUp() {
    return(
        <div>
            <h1>Hello from SignUp</h1>
        </div>
    )
}
export default SignUp;