import "./comp.css"
import "./comp2.css"
function Home() {
    return(
        <div>
            <h1>
            <section class="hero" id="home">
    <div>
      <h1>Welcome to FitLife Gym</h1>
      <p>Transform your life with expert fitness training and modern equipment.</p>
      <button>Join Now</button>
    </div>
  </section>

  <section class="features" id="about">
    <div class="feature">
      <h3>Modern Equipment</h3>
      <p>Top-of-the-line machines to suit all fitness goals.</p>
    </div>
    <div class="feature">
      <h3>Certified Trainers</h3>
      <p>Expert guidance to help you reach your goals faster.</p>
    </div>
    <div class="feature">
      <h3>Group Classes</h3>
      <p>Fun and energetic classes to keep you motivated.</p>
    </div>
    <div class="feature">
      <h3>Flexible Membership</h3>
      <p>Affordable plans designed to fit your lifestyle.</p>
    </div>
  </section>

 
  <footer class="footer">
    <p>&copy; 2025 FitLife Gym. All Rights Reserved.</p>
  </footer>
            </h1>
        </div>
    )
}
export default Home;