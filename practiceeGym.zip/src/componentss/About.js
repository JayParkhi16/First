import "./comp.css"
import "./compabout.css"

function About() {
    return(
        <div>
            <header class="header">
    <div>
      <h1>About Us</h1>
      <p>Your fitness journey starts here. Join a community dedicated to your health and well-being.</p>
    </div>
  </header>

  <div class="container">
    <section class="section">
      <h2>Our Mission</h2>
      <p>
        At our gym, we are committed to empowering you to achieve your fitness goals. With state-of-the-art facilities and expert trainers, we provide the support and motivation you need to succeed.
      </p>
    </section>

    <section class="section">
      <h2>Why Choose Us?</h2>
      <p>
        We offer a range of classes, personalized training programs, and modern equipment to suit all fitness levels. Our focus is on creating a welcoming and inclusive environment for everyone.
      </p>
    </section>

    <div class="section">
      <h2>Our Branches</h2>
      <div class="branch">
        <div class="branch-member">
          <img src="https://cdn.shopify.com/s/files/1/0141/5242/t/16/assets/fitsix-4-bright_LIQo.jpg?v=162012172235" />
          <h3>Mumbai</h3>
          <p>Andheri</p>
        </div>
        <div class="branch-member">
          <img src="https://cdn.prod.website-files.com/659e7a9b97f8951bca0d2bea/65d7398d9ea0beea1b3e4ae1_Gym%20layout.jpeg"/>
          <h3>Pune</h3>
          <p>Baner-Balewadi</p>
        </div>
        <div class="branch-member">
          <img src="https://images.squarespace-cdn.com/content/v1/5fdfeb249d00c472c28c8e82/1723582116139-A4A1K24EME4SH93MXG0N/DSC05170-min.jpg"/>
          <h3>Nagpur</h3>
          <p>Chhatrapati Square</p>
        </div>
      </div>
    </div>

    <div class="section">
      <a href="/signin" class="cta">Join Our Gym Today</a>
    </div>
    </div>
        </div>
    )
}
export default About;