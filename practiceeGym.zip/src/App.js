import { BrowserRouter, Route } from 'react-router-dom';
import { Routes } from 'react-router-dom';
import Home from './componentss/Home';
import SignIn from './componentss/SignIn';
import SignUp from './componentss/SignUp';
import About from './componentss/About';
import Navbar from './componentss/Navbar';
import './App.css';


function App() {
  return (
    <div>
       <BrowserRouter>
       <Navbar/>
       <Routes>
        <Route path='/' element={<Home/>}>Home</Route>
        <Route path='/signin' element={<SignIn/>}>SignIn</Route>
        <Route path='/signup' element={<SignUp/>}>SignUp</Route>
        <Route path='/about' element={<About/>}>About</Route>
       </Routes>
       </BrowserRouter>
    </div>
  );
}

export default App;
